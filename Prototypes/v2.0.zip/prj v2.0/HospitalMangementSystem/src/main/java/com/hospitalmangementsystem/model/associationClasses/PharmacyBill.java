/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hospitalmangementsystem.model.associationClasses;

/**
 *
 * @author user
 */
public class PharmacyBill {
    private String billNo;
    private String patientId;
    private String [] medicineId;
    private String [] quantity;

    public PharmacyBill(String billNo, String patientId) {
        this.billNo = billNo;
        this.patientId = patientId;
        this.medicineId = new String[5];
        this.quantity = new String[5];
        
        
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }
    
}
