/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.com.hospitalmangementsystem.controller;

import main.java.com.hospitalmangementsystem.view.ViewDoctor;
import main.java.com.hospitalmangementsystem.view.ViewLogin;

/**
 *
 * @author user
 */
public class MainController {
    
    private static String Id;
    
    public static void main(String[] args) {
        
        ViewLogin viewLogin = new ViewLogin();
     //   System.out.println("nwe");
     
        while (ControllerLogin.getLoginStatus() == -1){
            System.out.println("ControllerLogin.getLoginStatus()  " + ControllerLogin.getLoginStatus());
        }
        
        Id = viewLogin.getTxtLoginId();
                
       // System.out.println("ControllerLogin.getLoginStatus()  " + ControllerLogin.getLoginStatus());
        
        switch (ControllerLogin.getLoginStatus()) {
            case 1: ViewDoctor viewDoctor = new ViewDoctor();
                
                
            
                break;
        }

    }

    public static String getId() {
        return Id;
    }
    
    

}
