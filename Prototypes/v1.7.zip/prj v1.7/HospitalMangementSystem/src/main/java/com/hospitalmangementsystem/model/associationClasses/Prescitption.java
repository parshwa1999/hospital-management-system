/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hospitalmangementsystem.model.associationClasses;

/**
 *
 * @author user
 */
public class Prescitption {
    private String id;
    private String patientId;
    private String doctorId;
    private String medicineId1;
    private String medicineId2;    
    private String medicineId3;    
    private String medicineId4;
    private String medicineId5;
    private String dosage1;
    private String dosage2;    
    private String dosage3;    
    private String dosage4;
    private String dosage5;

    public Prescitption(String id, String patientId, String doctorId, String medicineId1, String medicineId2, String medicineId3, String medicineId4, String medicineId5, String dosage1, String dosage2, String dosage3, String dosage4, String dosage5) {
        this.id = id;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.medicineId1 = medicineId1;
        this.medicineId2 = medicineId2;
        this.medicineId3 = medicineId3;
        this.medicineId4 = medicineId4;
        this.medicineId5 = medicineId5;
        this.dosage1 = dosage1;
        this.dosage2 = dosage2;
        this.dosage3 = dosage3;
        this.dosage4 = dosage4;
        this.dosage5 = dosage5;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getMedicineId1() {
        return medicineId1;
    }

    public void setMedicineId1(String medicineId1) {
        this.medicineId1 = medicineId1;
    }

    public String getMedicineId2() {
        return medicineId2;
    }

    public void setMedicineId2(String medicineId2) {
        this.medicineId2 = medicineId2;
    }

    public String getMedicineId3() {
        return medicineId3;
    }

    public void setMedicineId3(String medicineId3) {
        this.medicineId3 = medicineId3;
    }

    public String getMedicineId4() {
        return medicineId4;
    }

    public void setMedicineId4(String medicineId4) {
        this.medicineId4 = medicineId4;
    }

    public String getMedicineId5() {
        return medicineId5;
    }

    public void setMedicineId5(String medicineId5) {
        this.medicineId5 = medicineId5;
    }

    public String getDosage1() {
        return dosage1;
    }

    public void setDosage1(String dosage1) {
        this.dosage1 = dosage1;
    }

    public String getDosage2() {
        return dosage2;
    }

    public void setDosage2(String dosage2) {
        this.dosage2 = dosage2;
    }

    public String getDosage3() {
        return dosage3;
    }

    public void setDosage3(String dosage3) {
        this.dosage3 = dosage3;
    }

    public String getDosage4() {
        return dosage4;
    }

    public void setDosage4(String dosage4) {
        this.dosage4 = dosage4;
    }

    public String getDosage5() {
        return dosage5;
    }

    public void setDosage5(String dosage5) {
        this.dosage5 = dosage5;
    }
    
    
    
}
