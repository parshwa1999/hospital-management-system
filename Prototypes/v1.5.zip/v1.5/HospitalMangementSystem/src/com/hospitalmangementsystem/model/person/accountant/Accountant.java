/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hospitalmangementsystem.model.person.accountant;

import com.hospitalmangementsystem.model.person.Person;

/**
 *
 * @author user
 */
public class Accountant extends Person{
    
    public Accountant(String id, String firstName, String lastName, String phoneNo, String address, String description, String dateOfBirth) {
        super(id, firstName, lastName, phoneNo, address, description, dateOfBirth);
    }
    
}
