/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.com.hospitalmangementsystem.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import main.java.com.hospitalmangementsystem.view.ViewPatientOpdHistory;

/**
 *
 * @author user
 */
public class ControllerPatientHistory {
    private ViewPatientOpdHistory view;

    public ControllerPatientHistory(ViewPatientOpdHistory view) {
        this.view = view;
        
        
        view.setButtonBehaviour(new PatHisBtnListner());
    }

    public class PatHisBtnListner implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
        
            
            
        
        }
        
    }
    
}
