/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.com.hospitalmangementsystem.controller;

import main.java.com.hospitalmangementsystem.model.login.Login;
import main.java.com.hospitalmangementsystem.view.ViewLogin;

/**
 *
 * @author user
 */
public class MainController {
    
    public static void main(String[] args) {
        Login modelLogin = new Login();

        ViewLogin viewLogin = new ViewLogin();

    
        
        
        
    }
    

    
}
